This module provide admin interface for users/admins has the access to modules 
page to reorder the module weights as they want.

INSTALLATION :
1. download the module and uncompresse it to sites/all/module and enable it
2. go to admin/config/system/modules-weight and reorder the modules weight :)

This module just display non-core module, that's because displaying core module in the configuration form will reorder the system core modules execution even if you didn't change them and as some might notice all core modules has 0 weight value by default.
Downloads