<div id="views_slideshow_controls_text_<?php print $variables['vss_id']; ?>" class="<?php print $classes; ?>">
  <?php print $rendered_control_previous; ?>
  <?php print $rendered_control_pause; ?>
  <?php print $rendered_control_next; ?>
</div>
